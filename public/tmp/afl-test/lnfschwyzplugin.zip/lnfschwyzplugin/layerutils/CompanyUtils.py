# -*- coding: utf-8 -*-
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    copyright            : (C) 2015 by Sandro Mani / Sourcepole AG
#    email                : smani@sourcepole.ch

from qgis.core import *
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from LayerUtils import LayerUtils
import os


class CompanyUtils:
    @staticmethod
    def setupAttributeDialog(layer):
        layer.clearAttributeEditorWidgets()
        layer.setFeatureFormSuppress(QgsVectorLayer.SuppressOff)
        layer.setEditForm(os.path.join(os.path.dirname(__file__), "CompanyDialog.ui"))
        layer.setEditFormInit("CompanyDialog.init")
        layer.tab = QgsAttributeEditorContainer("Betrieb", layer)
        layer.tab.widgets = dict()  # Just to keep a reference to the widgets, see LayerUtils.addEditWidget
        layer.addAttributeEditorWidget(layer.tab)

        if QGis.QGIS_VERSION_INT <= 20200:
            idx = LayerUtils.addEditWidgetOld(layer, "nr_gemeinde_bfs",
                                              u"Gemeinde",
                                              QgsVectorLayer.EditRange)
            layer.range(idx).mMin = 0
            layer.range(idx).mMax = 9999
            layer.range(idx).mStep = 1
            idx = LayerUtils.addEditWidgetOld(layer, "nr_zaehlkreis",
                                              u"Z\u00E4hlkreis",
                                              QgsVectorLayer.EditRange)
            layer.range(idx).mMin = 0
            layer.range(idx).mMax = 99
            layer.range(idx).mStep = 1
            idx = LayerUtils.addEditWidgetOld(layer, "nr_betrieb",
                                              u"Betriebsnummer",
                                              QgsVectorLayer.EditRange)
            layer.range(idx).mMin = 0
            layer.range(idx).mMax = 999
            layer.range(idx).mStep = 1
            idx = LayerUtils.addEditWidgetOld(layer, "nm_betrieb",
                                              u"Betriebsname",
                                              QgsVectorLayer.TextEdit)
        else:
            LayerUtils.addEditWidget(layer, "nr_gemeinde_bfs",
                                     u"Gemeinde",
                                     "Range",
                                     {"Step": 1, "Min": 0, "Max": 9999})
            LayerUtils.addEditWidget(layer, "nr_zaehlkreis",
                                     u"Z\u00E4hlkreis",
                                     "Range",
                                     {"Step": 1, "Min": 0, "Max": 99})
            LayerUtils.addEditWidget(layer, "nr_betrieb",
                                     u"Betriebsnummer",
                                     "Range",
                                     {"Step": 1, "Min": 0, "Max": 999})
            LayerUtils.addEditWidget(layer, "nm_betrieb",
                                     u"Betriebsname",
                                     "TextEdit",
                                     {"IsMultiline": False, "IsMultiline": False})
        idx = lambda name: layer.pendingFields().indexFromName(name)
        layer.addAttributeAlias(idx("nr_gemeinde_bfs"), "Gemeinde")
        layer.addAttributeAlias(idx("nr_zaehlkreis"), u"Z\u00E4hlkreis")
        layer.addAttributeAlias(idx("nr_betrieb"), "Betriebsnummer")
        layer.addAttributeAlias(idx("nm_betrieb"), "Betriebsname")
