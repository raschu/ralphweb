# -*- coding: utf-8 -*-
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    copyright            : (C) 2014 by Sandro Mani / Sourcepole AG
#    email                : smani@sourcepole.ch

from qgis.core import *
from PyQt4.QtCore import *
from PyQt4.QtGui import *
from LayerUtils import LayerUtils
from LandUseUtils import LandUseUtils
import os


class ManagementUnitsUtils:
    @staticmethod
    def setupAttributeDialog(layer, statusTextLayer, betriebTextLayer):
        layer.clearAttributeEditorWidgets()
        layer.setFeatureFormSuppress(QgsVectorLayer.SuppressOff)
        layer.setEditForm(os.path.join(os.path.dirname(__file__), "ManagementUnitDialog.ui"))
        layer.setEditFormInit("ManagementUnitDialog.init")
        layer.tab = QgsAttributeEditorContainer("Bewirtschaftungseinheit", layer)
        layer.tab.widgets = dict()  # Just to keep a reference to the widgets, see LayerUtils.addEditWidget
        layer.addAttributeEditorWidget(layer.tab)

        if QGis.QGIS_VERSION_INT <= 20200:
            idx = LayerUtils.addEditWidgetOld(layer, "sr_ist_definitiv",
                                              u"Ist definitiv",
                                              QgsVectorLayer.CheckBox)
            layer.setCheckedState(idx, "J", "N")
            idx = LayerUtils.addEditWidgetOld(layer, "nr_teilflaeche",
                                              u"Teilfl\u00E4chen Nr.",
                                              QgsVectorLayer.TextEdit)
            idx = LayerUtils.addEditWidgetOld(layer, "id_status",
                                              u"Status",
                                              QgsVectorLayer.ValueRelation)
            layer.valueRelation(idx).mLayer = statusTextLayer.id()
            layer.valueRelation(idx).mKey = "id"
            layer.valueRelation(idx).mValue = "tx_katalog_gui"
            layer.valueRelation(idx).mAllowNull = False
            layer.valueRelation(idx).mOrderByValue = True
            layer.valueRelation(idx).mAllowMulti = False
            idx = LayerUtils.addEditWidgetOld(layer, "id_betrieb",
                                              u"Betrieb",
                                              QgsVectorLayer.ValueRelation)
            layer.valueRelation(idx).mLayer = betriebTextLayer.id()
            layer.valueRelation(idx).mKey = "id"
            layer.valueRelation(idx).mValue = "tx_betrieb_gui"
            layer.valueRelation(idx).mAllowNull = True
            layer.valueRelation(idx).mOrderByValue = True
            layer.valueRelation(idx).mAllowMulti = False
            idx = LayerUtils.addEditWidgetOld(layer, "nr_av_parzelle",
                                              u"AV Parzelle",
                                              QgsVectorLayer.TextEdit)
        else:
            LayerUtils.addEditWidget(layer, "sr_ist_definitiv",
                                     u"Ist definitiv",
                                     "CheckBox",
                                     {"CheckedState": "J", "UncheckedState": "N"})
            LayerUtils.addEditWidget(layer, "nr_teilflaeche",
                                     u"Teilfl\u00E4chen Nr.",
                                     "TextEdit",
                                     {"IsMultiline": False})
            LayerUtils.addEditWidget(layer, "id_status",
                                     u"Status",
                                     "ValueRelation",
                                     {"OrderByValue": True, "AllowNull": False,
                                      "Key": "id", "Layer": statusTextLayer.id(),
                                      "Value": "tx_katalog_gui", "AllowMulti": False})
            LayerUtils.addEditWidget(layer, "id_betrieb",
                                     u"Betrieb",
                                     "ValueRelation",
                                     {"OrderByValue": True, "AllowNull": True,
                                      "Key": "id", "Layer": betriebTextLayer.id(),
                                      "Value": "tx_betrieb_gui", "AllowMulti": False})
            LayerUtils.addEditWidget(layer, "nr_av_parzelle",
                                     u"AV Parzelle",
                                     "TextEdit",
                                     {"IsMultiline": False})
        idx = lambda name: layer.pendingFields().indexFromName(name)
        layer.addAttributeAlias(idx("id_betrieb"), "Betrieb")
        layer.addAttributeAlias(idx("id_zone_ausland"), "Zone Ausland")
        layer.addAttributeAlias(idx("nr_gemeinde_bfs"), "Gemeinde")
        layer.addAttributeAlias(idx("nr_av_parzelle"), "AV Parzelle")

    @staticmethod
    def getOldGeometry(muLayer, id, editedMUs):
        oldGeometry = None
        try:
            oldGeometry = editedMUs[id]
        except:
            try:
                feature = LayerUtils.getFeatureById(muLayer.dataProvider(), id)
                oldGeometry = QgsGeometry(feature.geometry())
            except:
                pass
        return oldGeometry

    @staticmethod
    def checkGeometry(muLayer, luLayer, id, editedMUs):
        feature = LayerUtils.getFeatureById(muLayer, id)
        msg = ""
        if LayerUtils.checkFeatureIntersection(muLayer, feature):
            msg += "<li>%s</li>" % QObject().tr("The management unit intersects with other management units")
        msg += "".join(["<li>%s</li>" % err.what() for err in feature.geometry().validateGeometry()])
        # Check that all land use features within the affected area still completely lie within a management unit
        oldGeometry = ManagementUnitsUtils.getOldGeometry(muLayer, id, editedMUs)
        if oldGeometry:
            bbox = feature.geometry().boundingBox()
            bbox.combineExtentWith(oldGeometry.boundingBox())
            for luFeature in LayerUtils.getFeaturesByBoundingBox(luLayer, bbox):
                if not LandUseUtils.getParentManagementUnit(muLayer, luFeature):
                    msg += "<li>%s</li>" % QObject().tr("A land use unit does not lie completely within a management unit")
                    break
        if msg:
            QMessageBox.warning(None, QObject().tr("Invalid geometry"), "<p>%s<ul>%s</ul></p>" % (QObject().tr("The geometry is invalid:"), msg))
