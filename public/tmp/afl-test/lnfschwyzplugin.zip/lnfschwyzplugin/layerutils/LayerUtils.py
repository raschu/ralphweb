# -*- coding: utf-8 -*-
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    copyright            : (C) 2014 by Sandro Mani / Sourcepole AG
#    email                : smani@sourcepole.ch

from qgis.core import *
from PyQt4.QtCore import *


class LayerUtils:
    @staticmethod
    def load(iface, ds, key, name, group=None):
        # Load layer
        id = QgsProject.instance().readEntry("lnf", key, "")[0]
        if id:
            layer = QgsMapLayerRegistry.instance().mapLayer(id)
        else:
            layer = QgsVectorLayer(ds.uri(), name, "postgres")
            if not layer.isValid():
                raise Exception(QObject().tr("The layer \"%s\" is invalid. The message log might contain further details.") % name)
            QgsMapLayerRegistry.instance().addMapLayer(layer)
            QgsProject.instance().writeEntry("lnf", key, layer.id())
        if group is not None:
            iface.legendInterface().moveLayer(layer, group)
        return layer

    @staticmethod
    def addEditWidgetOld(layer, attribute, alias, editType):
        index = layer.pendingFields().indexFromName(attribute)
        assert(index > -1)
        layer.addAttributeAlias(index, alias)
        layer.setEditType(index, editType)
        layer.setFieldEditable(index, True)
        editor = QgsAttributeEditorField(alias, index, layer.tab)
        # Need to keep a reference around, otherwise editor ist destroyed when it goes out of scope
        layer.tab.widgets[index] = editor
        layer.tab.addChildElement(editor)
        return index

    @staticmethod
    def addEditWidget(layer, attribute, alias, editType, config=dict()):
        index = layer.pendingFields().indexFromName(attribute)
        assert(index > -1)
        layer.addAttributeAlias(index, alias)
        layer.setEditorWidgetV2(index, editType)
        layer.setEditorWidgetV2Config(index, config)
        layer.setFieldEditable(index, True)
        editor = QgsAttributeEditorField(alias, index, layer.tab)
        # Need to keep a reference around, otherwise editor ist destroyed when it goes out of scope
        layer.tab.widgets[index] = editor
        layer.tab.addChildElement(editor)

    @staticmethod
    def getFeatureById(layer, id):
        request = QgsFeatureRequest()
        request.setFilterFid(id)
        try:
            return layer.getFeatures(request).next()
        except:
            return None

    @staticmethod
    def getFeaturesByExpression(layer, expr):
        request = QgsFeatureRequest()
        request.setFilterExpression(expr)
        return layer.getFeatures(request)

    @staticmethod
    def getFeaturesByBoundingBox(layer, bbox):
        request = QgsFeatureRequest()
        request.setFilterRect(bbox)
        return layer.getFeatures(request)

    @staticmethod
    def checkFeatureIntersection(layer, testFeature):
        geometry = testFeature.geometry()
        for feature in LayerUtils.getFeaturesByBoundingBox(layer, geometry.boundingBox()):
            # 1E-4: touching but not otherwise intersecting geometries
            # sometimes are detected as intersecting
            if feature.id() != testFeature.id() and \
               geometry.intersection(feature.geometry()).area() > 1E-4:
                return True
        return False
