# -*- coding: utf-8 -*-
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    copyright            : (C) 2015 by Sandro Mani / Sourcepole AG
#    email                : smani@sourcepole.ch

from qgis.core import *
from qgis.gui import *
from PyQt4.QtCore import *
from PyQt4.QtGui import *
import os
import operator

instances = list()

translator = None


def init(dialog, layer, feature):
    global translator
    if not translator:
        locale = QSettings().value("locale/userLocale")[0:2]
        localePath = os.path.join(os.path.dirname(__file__), '..', 'i18n', 'lnfschwyz_{}.qm'.format(locale))

        if os.path.exists(localePath):
            translator = QTranslator()
            translator.load(localePath)
            QCoreApplication.installTranslator(translator)

    # Keep a reference alive
    global instances
    instances.append(ManagementUnitDialog(dialog, layer, feature))


class ManagementUnitDialog(QObject):
    def __init__(self, dialog, layer, feature):
        QObject.__init__(self)
        dialog.destroyed.connect(self.cleanup)

        for field in layer.pendingFields().toList():
            label = dialog.findChild(QLabel, "label_%s" % field.name())
            if label:
                label.setText(layer.attributeAlias(layer.pendingFields().indexFromName(field.name())))

        # Sort id_betrieb
        combo = dialog.findChild(QComboBox, "id_betrieb")
        combo.blockSignals(True)
        entries = []
        current = combo.currentIndex()
        for i in range(0, combo.count()):
            entries.append((i, combo.itemText(i), combo.itemData(i)))
        combo.clear()
        entries.sort(cmp=ManagementUnitDialog.sortBetriebId)
        for entry in entries:
            combo.addItem(entry[1], entry[2])
        try:
            combo.setCurrentIndex(map(operator.itemgetter(0), entries).index(current))
        except:
            combo.setCurrentIndex(-1)
        combo.blockSignals(False)

        # Install validator on nr_teilflaeche
        digits = layer.pendingFields().field("nr_teilflaeche").length()
        lineEdit = dialog.findChild(QLineEdit, "nr_teilflaeche")
        self.validator = QRegExpValidator(QRegExp("\\d{%d}" % digits), None)
        lineEdit.setValidator(self.validator)

    def cleanup(self):
        global instances
        instances.remove(self)

    @staticmethod
    def sortBetriebId(x, y):
        try:
            x = [int(n) for n in x[1].split('/')]
            y = [int(n) for n in y[1].split('/')]
            if x[0] - y[0] != 0:
                return x[0] - y[0]
            else:
                if x[1] - y[1] != 0:
                    return x[1] - y[1]
                else:
                    return x[2] - y[2]
        except:
            return 0
