# -*- coding: utf-8 -*-
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    copyright            : (C) 2014 by Sandro Mani / Sourcepole AG
#    email                : smani@sourcepole.ch

from qgis.core import *
from PyQt4.QtCore import *
from PyQt4.QtGui import *
import os
from LayerUtils import LayerUtils


class LandUseUtils:
    @staticmethod
    def setupAttributeDialog(layer, statusTextLayer, nutzungsartTextLayer):
        layer.clearAttributeEditorWidgets()
        layer.setFeatureFormSuppress(QgsVectorLayer.SuppressOff)
        layer.setEditForm(os.path.join(os.path.dirname(__file__), "LandUseDialog.ui"))
        layer.setEditFormInit("LandUseDialog.init")
        layer.tab = QgsAttributeEditorContainer("Nutzungseinheit", None)
        layer.tab.widgets = dict()  # Just to keep a reference to the widgets, see LayerUtils.addEditWidget
        layer.addAttributeEditorWidget(layer.tab)

        if QGis.QGIS_VERSION_INT <= 20200:
            idx = LayerUtils.addEditWidgetOld(layer, "wt_anzahl_baeume",
                                              u"Anzahl B\u00E4ume",
                                              QgsVectorLayer.EditRange)
            layer.range(idx).mMin = 0
            layer.range(idx).mMax = 9999
            layer.range(idx).mStep = 1
            idx = LayerUtils.addEditWidgetOld(layer, "wt_bewirtschaftungsgrad",
                                              u"Bewirtschaftungsgrad",
                                              QgsVectorLayer.EditRange)
            layer.range(idx).mMin = 0
            layer.range(idx).mMax = 999
            layer.range(idx).mStep = 1
            idx = LayerUtils.addEditWidgetOld(layer, "sr_beitragsberechtigt",
                                              u"Beitragsberechtigt",
                                              QgsVectorLayer.CheckBox)
            layer.setCheckedState(idx, "J", "N")
            idx = LayerUtils.addEditWidgetOld(layer, "sr_nutzung_im_beitragsjahr",
                                              u"Nutzung im Beitragsjahr",
                                              QgsVectorLayer.CheckBox)
            layer.setCheckedState(idx, "J", "N")
            idx = LayerUtils.addEditWidgetOld(layer, "sr_nhg",
                                              u"NHG",
                                              QgsVectorLayer.CheckBox)
            layer.setCheckedState(idx, "J", "N")
            idx = LayerUtils.addEditWidgetOld(layer, "sr_einzelkulturbeitrag",
                                              u"Einzelkulturbeitrag",
                                              QgsVectorLayer.CheckBox)
            layer.setCheckedState(idx, "J", "N")
            idx = LayerUtils.addEditWidgetOld(layer, "sr_ist_definitiv",
                                              u"Ist definitiv",
                                              QgsVectorLayer.CheckBox)
            layer.setCheckedState(idx, "J", "N")
            idx = LayerUtils.addEditWidgetOld(layer, "id_status",
                                              u"Status",
                                              QgsVectorLayer.ValueRelation)
            layer.valueRelation(idx).mLayer = statusTextLayer.id()
            layer.valueRelation(idx).mKey = "id"
            layer.valueRelation(idx).mValue = "tx_katalog_gui"
            layer.valueRelation(idx).mAllowNull = False
            layer.valueRelation(idx).mOrderByValue = True
            layer.valueRelation(idx).mAllowMulti = False
            idx = LayerUtils.addEditWidgetOld(layer, "id_nutzungsart",
                                              u"Nutzungsart",
                                              QgsVectorLayer.ValueRelation)
            layer.valueRelation(idx).mLayer = nutzungsartTextLayer.id()
            layer.valueRelation(idx).mKey = "id"
            layer.valueRelation(idx).mValue = "tx_nutzung_gui"
            layer.valueRelation(idx).mAllowNull = False
            layer.valueRelation(idx).mOrderByValue = True
            layer.valueRelation(idx).mAllowMulti = False
        else:
            LayerUtils.addEditWidget(layer, "wt_anzahl_baeume",
                                     u"Anzahl B\u00E4ume",
                                     "Range",
                                     {"Step": 1, "Min": 0, "Max": 9999})
            LayerUtils.addEditWidget(layer, "wt_bewirtschaftungsgrad",
                                     u"Bewirtschaftungsgrad",
                                     "Range",
                                     {"Step": 1, "Min": 0, "Max": 999})
            LayerUtils.addEditWidget(layer, "sr_beitragsberechtigt",
                                     u"Beitragsberechtigt",
                                     "CheckBox",
                                     {"CheckedState": "J", "UncheckedState": "N"})
            LayerUtils.addEditWidget(layer, "sr_nutzung_im_beitragsjahr",
                                     u"Nutzung im Beitragsjahr",
                                     "CheckBox",
                                     {"CheckedState": "J", "UncheckedState": "N"})
            LayerUtils.addEditWidget(layer, "sr_nhg",
                                     u"NHG",
                                     "CheckBox",
                                     {"CheckedState": "J", "UncheckedState": "N"})
            LayerUtils.addEditWidget(layer, "sr_einzelkulturbeitrag",
                                     u"Einzelkulturbeitrag",
                                     "CheckBox",
                                     {"CheckedState": "J", "UncheckedState": "N"})
            LayerUtils.addEditWidget(layer, "sr_ist_definitiv",
                                     u"Ist definitiv",
                                     "CheckBox",
                                     {"CheckedState": "J", "UncheckedState": "N"})
            LayerUtils.addEditWidget(layer, "id_status",
                                     u"Status",
                                     "ValueRelation",
                                     {"OrderByValue": True, "AllowNull": False,
                                      "Key": "id", "Layer": statusTextLayer.id(),
                                      "Value": "tx_katalog_gui", "AllowMulti": False})
            LayerUtils.addEditWidget(layer, "id_nutzungsart",
                                     u"Nutzungsart",
                                     "ValueRelation",
                                     {"OrderByValue": True, "AllowNull": False,
                                      "Key": "id", "Layer": nutzungsartTextLayer.id(),
                                      "Value": "tx_nutzung_gui", "AllowMulti": False})
        idx = lambda name: layer.pendingFields().indexFromName(name)
        layer.addAttributeAlias(idx("dt_vertrag_von"), "Vertrag von")
        layer.addAttributeAlias(idx("dt_vertrag_bis"), "Vertrag bis")
        layer.addAttributeAlias(idx("dt_schnittzeitpunkt"), "Schnitzeitpunkt")
        layer.addAttributeAlias(idx("nr_nutzung"), "Nutzungsidentifikator")
        layer.addAttributeAlias(idx("wt_groesse"), u"Gr\u00F6sse")
        layer.addAttributeAlias(idx("id_bewirtschaftungseinheit"), "Bewirtschaftungseinheit")

        join = QgsVectorJoinInfo()
        join.joinLayerId = nutzungsartTextLayer.id()
        join.joinFieldName = "id"
        join.targetFieldName = "id_nutzungsart"
        join.memoryCache = True
        layer.addJoin(join)

    @staticmethod
    def getParentManagementUnit(muLayer, luFeature):
        luGeometry = luFeature.geometry()
        for feature in LayerUtils.getFeaturesByBoundingBox(muLayer, luGeometry.boundingBox()):
            if luGeometry.within(feature.geometry()):
                return feature["FID"]
        return None

    @staticmethod
    def adjustLandUseFeatures(luLayer, muLayer, changedMUBBox, iface):
        luLayer.setReadOnly(False)
        luLayer.startEditing()
        # Collect land unit features which were affected by a management unit geometry change
        for luFeature in LayerUtils.getFeaturesByBoundingBox(luLayer, changedMUBBox):
            luLayer.blockSignals(True)
            # Get management units which land unit intersects with, for each intersection add a new land unit, copying attributes
            for muFeature in LayerUtils.getFeaturesByBoundingBox(muLayer, luFeature.geometry().boundingBox()):
                inter = luFeature.geometry().intersection(muFeature.geometry())
                if not inter.isGeosEmpty():
                    geoms = []
                    if QGis.isMultiType(inter.wkbType()):
                        geoms += inter.asGeometryCollection()
                    else:
                        geoms.append(inter)
                    for geom in geoms:
                        if not geom.wkbType() == QGis.WKBPolygon:
                            # QMessageBox.warning(None, QObject().tr("Incorrect geometry type"), QObject().tr("Skipping feature with bad geometry type %d") % geom.wkbType())
                            continue
                        fields = luLayer.pendingFields()
                        newLuFeature = QgsFeature(fields)
                        newLuFeature.setGeometry(geom)
                        newLuFeature.setAttributes(luFeature.attributes())
                        newLuFeature["ID_BEWIRTSCHAFTUNGSEINHEIT"] = muFeature["FID"]
                        luLayer.addFeature(newLuFeature)
            luLayer.blockSignals(False)
            luLayer.deleteFeature(luFeature.id())

        iface.mapCanvas().refresh()

        dialog = QMessageBox(QMessageBox.Question, QObject().tr("Accept changes?"), QObject().tr("Do you want to accept the changes to the land use layer?"), QMessageBox.Yes | QMessageBox.No, iface.mainWindow())
        dialog.setModal(False)
        evloop = QEventLoop()
        dialog.finished.connect(evloop.quit)
        dialog.show()
        evloop.exec_()
        if dialog.clickedButton() == dialog.button(QMessageBox.Yes) and luLayer.commitChanges():
            luLayer.setReadOnly(True)
            return True
        else:
            luLayer.rollBack()
            luLayer.setReadOnly(False)
            iface.mapCanvas().refresh()
            return False

    @staticmethod
    def checkGeometry(luLayer, muLayer, id):
        feature = LayerUtils.getFeatureById(luLayer, id)
        msg = ""
        if LayerUtils.checkFeatureIntersection(luLayer, feature):
            msg += "<li>%s</li>" % QObject().tr("The land use unit intersects with other land use units")
        parent = LandUseUtils.getParentManagementUnit(muLayer, feature)
        if not parent:
            msg += "<li>%s</li>" % QObject().tr("The land use unit does not lie completely within a management unit")
        else:
            luLayer.changeAttributeValue(id, luLayer.fieldNameIndex("id_bewirtschaftungseinheit"), parent)
        msg += "".join(["<li>%s</li>" % err.what() for err in feature.geometry().validateGeometry()])
        if msg:
            QMessageBox.warning(None, QObject().tr("Invalid geometry"), "<p>%s<ul>%s</ul></p>" % (QObject().tr("The geometry is invalid:"), msg))
