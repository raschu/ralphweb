# -*- coding: utf-8 -*-
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    copyright            : (C) 2015 by Sandro Mani / Sourcepole AG
#    email                : smani@sourcepole.ch

from qgis.core import *
from qgis.gui import *
from PyQt4.QtCore import *
from PyQt4.QtGui import *
import os
from LandUseUtils import LandUseUtils

instances = list()

translator = None


def init(dialog, layer, feature):
    global translator
    if not translator:
        locale = QSettings().value("locale/userLocale")[0:2]
        localePath = os.path.join(os.path.dirname(__file__), '..', 'i18n', 'lnfschwyz_{}.qm'.format(locale))

        if os.path.exists(localePath):
            translator = QTranslator()
            translator.load(localePath)
            QCoreApplication.installTranslator(translator)

    # Keep a reference alive
    global instances
    instances.append(LandUseDialog(dialog, layer, feature))


class LandUseDialog(QObject):
    def __init__(self, dialog, layer, feature):
        QObject.__init__(self)
        dialog.destroyed.connect(self.cleanup)

        id = QgsProject.instance().readEntry("lnf", "muLayer", "")[0]
        if id:
            self.muLayer = QgsMapLayerRegistry.instance().mapLayer(id)
        else:
            self.muLayer = None
        self.luLayer = layer
        self.featureid = feature.id()
        self.dialog = dialog
        # self.rubbberband = None

        for field in layer.pendingFields().toList():
            label = self.dialog.findChild(QLabel, "label_%s" % field.name())
            if label:
                label.setText(layer.attributeAlias(layer.pendingFields().indexFromName(field.name())))

        self.btnselect = self.dialog.findChild(QToolButton, "btn_select_bewirtschaftungseinheit")
        self.btnhighlight = self.dialog.findChild(QToolButton, "btn_highlight_bewirtschaftungseinheit")
        self.btnselect.setToolTip(self.tr("Set to selected management unit"))
        self.btnhighlight.setToolTip(self.tr("Highlight parent management unit"))
        self.btnselect.setIcon(QIcon(":/images/themes/default/mActionSelect.svg"))
        self.btnhighlight.setIcon(QIcon(":/images/themes/default/mActionZoomToSelected.svg"))

        self.luLayer.editingStarted.connect(self.editingStarted)
        self.luLayer.editingStopped.connect(self.editingStopped)

        self.btnselect.setEnabled(layer.isEditable())

        self.managementUnitEditor = self.dialog.findChild(QLineEdit, "id_bewirtschaftungseinheit")
        self.managementUnitEditor.setReadOnly(True)
        self.btnselect.clicked.connect(self.selectManagementUnit)
        self.btnhighlight.clicked.connect(self.highlightManagementUnit)

        # When opening the attribute table, for some reason this function is executed
        # and the passed feature has no fields?
        try:
            if str(feature.attribute("id_bewirtschaftungseinheit")) == 'NULL':
                parentMU = LandUseUtils.getParentManagementUnit(self.muLayer, feature)
                if parentMU:
                    idx = self.luLayer.pendingFields().indexFromName("id_bewirtschaftungseinheit")
                    self.luLayer.changeAttributeValue(self.featureid, idx, parentMU)
                    self.managementUnitEditor.setText(parentMU)
        except:
            pass

    def editingStarted(self):
        self.btnselect.setEnabled(True)
        self.managementUnitEditor.setReadOnly(True)

    def editingStopped(self):
        self.btnselect.setEnabled(False)
        self.managementUnitEditor.setReadOnly(True)
        feature = QgsFeature()
        if self.luLayer.getFeatures(QgsFeatureRequest(self.featureid)).nextFeature(feature):
            id = feature.attribute("id_bewirtschaftungseinheit")
            if id:
                self.managementUnitEditor.setText(id)

    def cleanup(self):
        # if self.rubbberband:
        #     self.iface.mapCanvas().scene().removeItem(self.rubberBand)
        global instances
        instances.remove(self)

    def selectManagementUnit(self):
        features = self.muLayer.selectedFeatures()
        if len(features) != 1:
            QMessageBox.critical(self.dialog, self.tr("Error"), self.tr("Please select exactly one management unit"))
        else:
            parentMU = features[0].attribute("FID")
            idx = self.luLayer.pendingFields().indexFromName("id_bewirtschaftungseinheit")
            self.luLayer.changeAttributeValue(self.featureid, idx, parentMU)
            self.managementUnitEditor.setText(parentMU)

    def highlightManagementUnit(self):
        uuid = self.managementUnitEditor.text()
        r = QgsFeatureRequest()
        r.setFilterExpression("fid = '%s'" % uuid)
        f = QgsFeature()
        if not self.muLayer.getFeatures(r).nextFeature(f):
            QMessageBox.warning(self.dialog, self.tr("No match"), self.tr("Parent management unit is invalid"))
        else:
            # if self.rubbberband:
            #     self.iface.mapCanvas().scene().removeItem(self.rubberBand)
            # self.rubbberband = QgsRubberBand(self.iface.mapCanvas(), True)
            # self.rubbberband.setColor(Qt.yellow)
            # self.rubbberband.setWidth(2)
            # self.rubbberband.setToGeometry(f.geometry(), self.muLayer)

            self.muLayer.setSelectedFeatures([f.id()])

