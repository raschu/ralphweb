# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui_search.ui'
#
# Created: Mon Dec  1 11:29:41 2014
#      by: PyQt4 UI code generator 4.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_searchDlg(object):
    def setupUi(self, searchDlg):
        searchDlg.setObjectName(_fromUtf8("searchDlg"))
        searchDlg.resize(404, 236)
        self.gridLayout = QtGui.QGridLayout(searchDlg)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label_2 = QtGui.QLabel(searchDlg)
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout.addWidget(self.label_2, 5, 0, 1, 1)
        self.cmbCompanyNo = QtGui.QComboBox(searchDlg)
        self.cmbCompanyNo.setObjectName(_fromUtf8("cmbCompanyNo"))
        self.gridLayout.addWidget(self.cmbCompanyNo, 6, 1, 2, 2)
        self.cmbMunicipality = QtGui.QComboBox(searchDlg)
        self.cmbMunicipality.setObjectName(_fromUtf8("cmbMunicipality"))
        self.gridLayout.addWidget(self.cmbMunicipality, 2, 1, 1, 2)
        self.label_3 = QtGui.QLabel(searchDlg)
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.gridLayout.addWidget(self.label_3, 6, 0, 2, 1)
        spacerItem = QtGui.QSpacerItem(20, 145, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.gridLayout.addItem(spacerItem, 8, 1, 1, 1)
        self.label = QtGui.QLabel(searchDlg)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 2, 0, 1, 1)
        self.cmbParcelNo = QtGui.QComboBox(searchDlg)
        self.cmbParcelNo.setObjectName(_fromUtf8("cmbParcelNo"))
        self.gridLayout.addWidget(self.cmbParcelNo, 5, 1, 1, 2)
        spacerItem1 = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.gridLayout.addItem(spacerItem1, 1, 0, 1, 1)
        self.label_4 = QtGui.QLabel(searchDlg)
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.label_4.setFont(font)
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.gridLayout.addWidget(self.label_4, 0, 0, 1, 3)
        self.line = QtGui.QFrame(searchDlg)
        self.line.setFrameShape(QtGui.QFrame.HLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName(_fromUtf8("line"))
        self.gridLayout.addWidget(self.line, 4, 0, 1, 3)
        self.buttonBox = QtGui.QDialogButtonBox(searchDlg)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Close)
        self.buttonBox.setObjectName(_fromUtf8("buttonBox"))
        self.gridLayout.addWidget(self.buttonBox, 9, 0, 1, 3)
        self.label_5 = QtGui.QLabel(searchDlg)
        self.label_5.setObjectName(_fromUtf8("label_5"))
        self.gridLayout.addWidget(self.label_5, 3, 0, 1, 1)
        self.cmbZaelkreis = QtGui.QComboBox(searchDlg)
        self.cmbZaelkreis.setObjectName(_fromUtf8("cmbZaelkreis"))
        self.gridLayout.addWidget(self.cmbZaelkreis, 3, 1, 1, 2)

        self.retranslateUi(searchDlg)
        QtCore.QMetaObject.connectSlotsByName(searchDlg)

    def retranslateUi(self, searchDlg):
        searchDlg.setWindowTitle(_translate("searchDlg", "Search", None))
        self.label_2.setText(_translate("searchDlg", "Parcel No.:", None))
        self.label_3.setText(_translate("searchDlg", "Company No.:", None))
        self.label.setText(_translate("searchDlg", "Municipality:", None))
        self.label_4.setText(_translate("searchDlg", "Zoom to:", None))
        self.label_5.setText(_translate("searchDlg", "Zaehlkreis:", None))

