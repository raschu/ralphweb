# -*- coding: utf-8 -*-
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    copyright            : (C) 2014 by Sandro Mani / Sourcepole AG
#    email                : smani@sourcepole.ch

from PyQt4.QtGui import *
from PyQt4.QtCore import *
from qgis.core import *
from qgis.gui import *
from ui_search import Ui_searchDlg
import re

from lnfschwyzplugin.dbtools.dbTools import DbObj
from lnfschwyzplugin.layerutils.LayerUtils import LayerUtils


class SearchDialog(QDialog, Ui_searchDlg):
    def __init__(self, iface, dbUri, luLayer, muLayer, parcelLayer, parent=None):
        QDialog.__init__(self, parent)
        self.setupUi(self)
        self.iface = iface
        self.rubberBands = []
        self.foundFeatures = []
        self.foundLayer = None

        # Select features on_button
        self.btnSelectFeatures = QPushButton(self)
        self.btnSelectFeatures.setText(self.tr("Select features"))
        self.btnSelectFeatures.clicked.connect(self.selectFeatures)
        self.btnSelectFeatures.setEnabled(False)
        self.buttonBox.addButton(self.btnSelectFeatures, QDialogButtonBox.ActionRole)

        # Try opening DB
        ds = QgsDataSourceURI(dbUri)
        self.db = DbObj("LNF-SZ", "pg", ds.host(), ds.port(), ds.database(), ds.username(), ds.password())
        if not self.db.isOpen():
            QMessageBox.critical(self.iface.mainWindow(), self.tr("Error"), self.tr("Unable to connect to the database, search will not work."))
            return

        self.luLayer = luLayer
        self.muLayer = muLayer
        self.parcelLayer = parcelLayer

        # Populate comboboxes
        result = self.db.read("SELECT DISTINCT gde_name, fosnr FROM a004b.r20a00_own_realestate ORDER BY gde_name")
        if "GDE_NAME" not in result:
            QMessageBox.warning(self, self.tr("Missing column"), self.tr("The column '%s' is missing in '%s'.") % ("GDE_NAME", "a004b.r20a00_own_realestate"))
            return
        for i in range(0, len(result["GDE_NAME"])):
            self.cmbMunicipality.addItem(result["GDE_NAME"][i], int(result["FOSNR"][i]))

        result = self.db.read("SELECT DISTINCT CAST(nr_zaehlkreis AS INTEGER) from a001a.f02_be_betrieb ORDER BY nr_zaehlkreis")
        if "NR_ZAEHLKREIS" not in result:
            QMessageBox.warning(self, self.tr("Missing column"), self.tr("The column '%s' is missing in '%s'.") % ("NR_ZAEHLKREIS", "a001a.f02_be_betrieb"))
            return
        for nr_zaehlkreis in result["NR_ZAEHLKREIS"]:
            self.cmbZaelkreis.addItem(nr_zaehlkreis, int(nr_zaehlkreis))

        self.cmbMunicipality.setCurrentIndex(-1)
        self.cmbZaelkreis.setCurrentIndex(-1)
        self.cmbParcelNo.setEnabled(False)
        self.cmbCompanyNo.setEnabled(False)
        self.cmbMunicipality.currentIndexChanged.connect(self.populateParcelSearch)
        self.cmbMunicipality.currentIndexChanged.connect(self.populateCompanySearch)
        self.cmbZaelkreis.currentIndexChanged.connect(self.populateCompanySearch)

    def closeEvent(self, ev):
        self.clearSearchResult()
        self.iface.mapCanvas().refresh()
        try:
            self.db.close()
        except:
            pass

    def layerFilter(self, table, geomcolumn, layer, exp):
        result = self.db.read("SELECT ST_Extent(%s) FROM %s WHERE %s;" % (geomcolumn, table, exp))
        if "ST_EXTENT" not in result:
            return
        pat = re.compile(r"BOX\(([-+]?[0-9]*\.?[0-9]*) ([-+]?[0-9]*\.?[0-9]*),([-+]?[0-9]*\.?[0-9]*) ([-+]?[0-9]*\.?[0-9]*)\)")
        match = re.match(pat, result["ST_EXTENT"][0])
        bbox = QgsRectangle(float(match.group(1)), float(match.group(2)), float(match.group(3)), float(match.group(4)))

        exp = QgsExpression(exp)
        exp.prepare(layer.pendingFields())
        for feature in layer.getFeatures(QgsFeatureRequest(bbox)):
            if exp.evaluate(feature):
                yield feature.id()

    def populateParcelSearch(self):
        self.cmbParcelNo.clear()
        self.cmbParcelNo.setEditable(False)
        self.cmbParcelNo.setEnabled(False)
        if self.cmbMunicipality.currentIndex() < 0:
            return
        fosnr = self.cmbMunicipality.itemData(self.cmbMunicipality.currentIndex())
        result = self.db.read("SELECT number FROM a004b.r20a00_own_realestate WHERE fosnr = %d ORDER BY CAST(regexp_replace(number, '^(\\d+).*$','\\1','g') as REAL)" % fosnr)
        if "NUMBER" in result:
            for entry in result["NUMBER"]:
                self.cmbParcelNo.addItem(entry)
            self.cmbParcelNo.setCurrentIndex(-1)
            self.cmbParcelNo.setEnabled(True)
        else:
            self.cmbParcelNo.setEditable(True)
            self.cmbParcelNo.setEditText(self.tr("No parcels"))

    def populateCompanySearch(self):
        self.cmbCompanyNo.clear()
        self.cmbCompanyNo.setEditable(False)
        self.cmbCompanyNo.setEnabled(False)
        if self.cmbMunicipality.currentIndex() < 0 or self.cmbZaelkreis.currentIndex() < 0:
            return
        nr_gemeinde_bfs = self.cmbMunicipality.itemData(self.cmbMunicipality.currentIndex())
        nr_zaehlkreis = self.cmbZaelkreis.itemData(self.cmbZaelkreis.currentIndex())
        result = self.db.read("SELECT DISTINCT CAST(nr_betrieb AS INTEGER) FROM a001a.f02_be_betrieb WHERE nr_gemeinde_bfs = %d AND nr_zaehlkreis = %d ORDER BY nr_betrieb" % (nr_gemeinde_bfs, nr_zaehlkreis))
        if "NR_BETRIEB" in result:
            for entry in result["NR_BETRIEB"]:
                if entry != "None":
                    self.cmbCompanyNo.addItem(entry)
        self.cmbCompanyNo.setCurrentIndex(-1)
        if self.cmbCompanyNo.count() > 0:
            self.cmbCompanyNo.setEnabled(True)
        else:
            self.cmbCompanyNo.setEditable(True)
            self.cmbCompanyNo.setEditText(self.tr("No companies"))

    def clearSearchResult(self):
        if self.rubberBands:
            for rubberBand in self.rubberBands:
                self.iface.mapCanvas().scene().removeItem(rubberBand)
        self.rubberBands = []
        self.foundFeatures = []
        self.foundLayer = None
        self.btnSelectFeatures.setEnabled(False)

    def highlightFeatures(self, layer, featureids):
        self.clearSearchResult()
        bbox = None
        for featureid in featureids:
            self.foundFeatures.append(featureid)
            feature = LayerUtils.getFeatureById(layer, featureid)
            rb = QgsRubberBand(self.iface.mapCanvas(), True)
            rb.setColor(Qt.yellow)
            rb.setWidth(2)
            rb.setToGeometry(feature.geometry(), layer)
            self.rubberBands.append(rb)
            if bbox:
                bbox.unionRect(feature.geometry().boundingBox())
            else:
                bbox = feature.geometry().boundingBox()
        if not self.rubberBands:
            QMessageBox.information(self, self.tr("No results"), self.tr("No results were found"))
        else:
            self.iface.mapCanvas().setExtent(bbox)
            self.iface.mapCanvas().refresh()
            self.btnSelectFeatures.setEnabled(True)
            self.foundLayer = layer

    def selectFeatures(self):
        self.foundLayer.setSelectedFeatures(self.foundFeatures)

    def populateParcelAndCompany(self, index):
        if self.cmbMunicipality.currentIndex() >= 0 and self.cmbZaelkreis.currentIndex() >= 0:
            self.populateParcelSearch()
            self.populateCompanySearch()

    @pyqtSignature("int")
    def on_cmbParcelNo_activated(self, index):
        if index > -1:
            self.setCursor(Qt.BusyCursor)
            self.cmbCompanyNo.setCurrentIndex(-1)
            number = self.cmbParcelNo.currentText()
            fosnr = self.cmbMunicipality.itemData(self.cmbMunicipality.currentIndex())
            expr = "number = '%s' and fosnr = %d" % (number, fosnr)
            featureids = self.layerFilter("a004b.r20a00_own_realestate", "geometry", self.parcelLayer, expr)
            self.highlightFeatures(self.parcelLayer, featureids)
            self.unsetCursor()

    @pyqtSignature("int")
    def on_cmbCompanyNo_activated(self, index):
        if index > -1:
            self.setCursor(Qt.BusyCursor)
            self.cmbParcelNo.setCurrentIndex(-1)
            nr_betrieb = int(self.cmbCompanyNo.currentText())
            nr_gemeinde_bfs = self.cmbMunicipality.itemData(self.cmbMunicipality.currentIndex())
            nr_zaehlkreis = self.cmbZaelkreis.itemData(self.cmbZaelkreis.currentIndex())
            result = self.db.read("SELECT id FROM a001a.f03_be_bewirtschaftungseinheit WHERE id_betrieb IN "
                                  "(SELECT id FROM a001a.f02_be_betrieb WHERE nr_betrieb = %d AND nr_gemeinde_bfs = %d AND nr_zaehlkreis = %d)"
                                  % (nr_betrieb, nr_gemeinde_bfs, nr_zaehlkreis))
            if "ID" in result:
                expr = ""
                for fid in result["ID"]:
                    expr += "fid = '%s' OR " % fid
                featureids = self.layerFilter("a001a.bewirtschaftungseinheit_v", "gm_flaeche", self.muLayer, expr[:-4])
                self.highlightFeatures(self.muLayer, featureids)
            self.unsetCursor()

    @pyqtSignature("")
    def on_buttonBox_rejected(self):
        self.close()
