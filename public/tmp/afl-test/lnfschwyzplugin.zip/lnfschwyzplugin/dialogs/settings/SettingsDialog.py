# -*- coding: utf-8 -*-
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    copyright            : (C) 2014 by Sandro Mani / Sourcepole AG
#    email                : smani@sourcepole.ch

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *

from lnfschwyzplugin.dbtools.dbTools import DbObj
from ui_settingsDialog import Ui_settingsDialog


class SettingsDialog(QDialog, Ui_settingsDialog):

    PATH = "/agriareas-Settings"

    def __init__(self, parent=None):
        QDialog.__init__(self, parent)
        self.setupUi(self)

    def run(self):
        datasource = QgsDataSourceURI(self.getDBConnectionURI())
        self.hostLineEdit.setText(datasource.host())
        self.portLineEdit.setText(datasource.port())
        self.dbnameLineEdit.setText(datasource.database())
        self.usernameLineEdit.setText(datasource.username())
        self.passwdLineEdit.setText(datasource.password())

        while True:
            if self.exec_() == QDialog.Accepted:
                host = self.hostLineEdit.text()
                port = self.portLineEdit.text()
                dbse = self.dbnameLineEdit.text()
                user = self.usernameLineEdit.text()
                pswd = self.passwdLineEdit.text()
                # Validate the connection information
                try:
                    db = DbObj("LNF-SZ", "pg", host, port, dbse, user, pswd)
                except:
                    continue
                if not db.isOpen():
                    continue
                db.close()

                # If valid, return URI
                datasource.setConnection(host, port, dbse, user, pswd)
                QSettings().setValue("/agriareas-Settings/dbConnection", datasource.uri())
                return datasource.uri()
            else:
                return ""

    def getDBConnectionURI(self):
        return QSettings().value("/agriareas-Settings/dbConnection", "")
