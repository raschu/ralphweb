# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui_settingsDialog.ui'
#
# Created: Fri May  9 15:33:47 2014
#      by: PyQt4 UI code generator 4.10.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_settingsDialog(object):
    def setupUi(self, settingsDialog):
        settingsDialog.setObjectName(_fromUtf8("settingsDialog"))
        settingsDialog.resize(400, 300)
        self.verticalLayout = QtGui.QVBoxLayout(settingsDialog)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.groupBox = QtGui.QGroupBox(settingsDialog)
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.gridLayout_2 = QtGui.QGridLayout(self.groupBox)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.hostLabel = QtGui.QLabel(self.groupBox)
        self.hostLabel.setObjectName(_fromUtf8("hostLabel"))
        self.gridLayout_2.addWidget(self.hostLabel, 0, 0, 1, 1)
        self.hostLineEdit = QtGui.QLineEdit(self.groupBox)
        self.hostLineEdit.setObjectName(_fromUtf8("hostLineEdit"))
        self.gridLayout_2.addWidget(self.hostLineEdit, 0, 1, 1, 1)
        self.portLabel = QtGui.QLabel(self.groupBox)
        self.portLabel.setObjectName(_fromUtf8("portLabel"))
        self.gridLayout_2.addWidget(self.portLabel, 1, 0, 1, 1)
        self.portLineEdit = QtGui.QLineEdit(self.groupBox)
        self.portLineEdit.setObjectName(_fromUtf8("portLineEdit"))
        self.gridLayout_2.addWidget(self.portLineEdit, 1, 1, 1, 1)
        self.dbnameLabel = QtGui.QLabel(self.groupBox)
        self.dbnameLabel.setObjectName(_fromUtf8("dbnameLabel"))
        self.gridLayout_2.addWidget(self.dbnameLabel, 2, 0, 1, 1)
        self.dbnameLineEdit = QtGui.QLineEdit(self.groupBox)
        self.dbnameLineEdit.setObjectName(_fromUtf8("dbnameLineEdit"))
        self.gridLayout_2.addWidget(self.dbnameLineEdit, 2, 1, 1, 1)
        self.usernameLabel = QtGui.QLabel(self.groupBox)
        self.usernameLabel.setObjectName(_fromUtf8("usernameLabel"))
        self.gridLayout_2.addWidget(self.usernameLabel, 3, 0, 1, 1)
        self.usernameLineEdit = QtGui.QLineEdit(self.groupBox)
        self.usernameLineEdit.setObjectName(_fromUtf8("usernameLineEdit"))
        self.gridLayout_2.addWidget(self.usernameLineEdit, 3, 1, 1, 1)
        self.passwdLabel = QtGui.QLabel(self.groupBox)
        self.passwdLabel.setObjectName(_fromUtf8("passwdLabel"))
        self.gridLayout_2.addWidget(self.passwdLabel, 4, 0, 1, 1)
        self.passwdLineEdit = QtGui.QLineEdit(self.groupBox)
        self.passwdLineEdit.setEchoMode(QtGui.QLineEdit.Password)
        self.passwdLineEdit.setObjectName(_fromUtf8("passwdLineEdit"))
        self.gridLayout_2.addWidget(self.passwdLineEdit, 4, 1, 1, 1)
        self.verticalLayout.addWidget(self.groupBox)
        self.buttonBox = QtGui.QDialogButtonBox(settingsDialog)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName(_fromUtf8("buttonBox"))
        self.verticalLayout.addWidget(self.buttonBox)

        self.retranslateUi(settingsDialog)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("accepted()")), settingsDialog.accept)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("rejected()")), settingsDialog.reject)
        QtCore.QMetaObject.connectSlotsByName(settingsDialog)

    def retranslateUi(self, settingsDialog):
        settingsDialog.setWindowTitle(_translate("settingsDialog", "Settings", None))
        self.groupBox.setTitle(_translate("settingsDialog", "Database connection", None))
        self.hostLabel.setText(_translate("settingsDialog", "Host:", None))
        self.portLabel.setText(_translate("settingsDialog", "Port:", None))
        self.dbnameLabel.setText(_translate("settingsDialog", "DB Name:", None))
        self.usernameLabel.setText(_translate("settingsDialog", "Username:", None))
        self.passwdLabel.setText(_translate("settingsDialog", "Password:", None))

