<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0" language="de_CH" sourcelanguage="">
<context>
    <name>@default</name>
    <message>
        <location filename="layerutils/LandUseUtils.py" line="196"/>
        <source>The land use unit intersects with other land use units</source>
        <translation>Die Nutzungseinheit überschneidet sich mit anderen Nutzungseinheiten</translation>
    </message>
    <message>
        <location filename="layerutils/LandUseUtils.py" line="199"/>
        <source>The land use unit does not lie completely within a management unit</source>
        <translation>Die Nutzungseinheit liegt nicht komplett innerhalb einer Bewritschaftungseinheit</translation>
    </message>
    <message>
        <location filename="layerutils/ManagementUnitsUtils.py" line="124"/>
        <source>Invalid geometry</source>
        <translation>Ungültige Geometrie</translation>
    </message>
    <message>
        <location filename="layerutils/ManagementUnitsUtils.py" line="124"/>
        <source>The geometry is invalid:</source>
        <translation>Die Geometrie ist ungültig:</translation>
    </message>
    <message>
        <location filename="layerutils/LayerUtils.py" line="25"/>
        <source>The layer &quot;%s&quot; is invalid. The message log might contain further details.</source>
        <translation>Der Layer &quot;%s&quot; ist ungültig. Das Protokoll könnte weitere Details enthalten.  </translation>
    </message>
    <message>
        <location filename="layerutils/ManagementUnitsUtils.py" line="112"/>
        <source>The management unit intersects with other management units</source>
        <translation>Die Bewirtschaftungseinheit überschneidet sich mit anderen Bewirtschaftungseinheiten</translation>
    </message>
    <message>
        <location filename="layerutils/ManagementUnitsUtils.py" line="121"/>
        <source>A land use unit does not lie completely within a management unit</source>
        <translation>Eine Landnutzungseinheit liegt nicht komplett innerhalb einer Bewritschaftungseinheit</translation>
    </message>
    <message>
        <location filename="layerutils/LandUseUtils.py" line="175"/>
        <source>Accept changes?</source>
        <translation>Änderungen übernehmen?</translation>
    </message>
    <message>
        <location filename="layerutils/LandUseUtils.py" line="175"/>
        <source>Do you want to accept the changes to the land use layer?</source>
        <translation>Sollten die Änderungen an den Nutzungseinheiten übernommen werden?</translation>
    </message>
</context>
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="dialogs/about/AboutDialog.py" line="23"/>
        <source>About %s %s</source>
        <translation>Über %s %s</translation>
    </message>
    <message>
        <location filename="dialogs/about/AboutDialog.py" line="24"/>
        <source>Version: %s</source>
        <translation>Version: %s</translation>
    </message>
    <message>
        <location filename="dialogs/about/AboutDialog.py" line="26"/>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <location filename="dialogs/about/AboutDialog.py" line="27"/>
        <source>Contact</source>
        <translation>Kontakt</translation>
    </message>
    <message>
        <location filename="dialogs/about/AboutDialog.py" line="28"/>
        <source>Change Log</source>
        <translation>Changelog</translation>
    </message>
    <message>
        <location filename="dialogs/about/AboutDialog.py" line="32"/>
        <source>Author(s):</source>
        <translation>Autor(en):</translation>
    </message>
    <message>
        <location filename="dialogs/about/AboutDialog.py" line="35"/>
        <source>Sourcepole AG - Linux &amp; Open Source Solutions</source>
        <translation>Sourcepole AG - Linux &amp; Open Source Solution</translation>
    </message>
    <message>
        <location filename="dialogs/about/AboutDialog.py" line="36"/>
        <source>Weberstrasse 5, 8004 Z&#xfc;rich, Switzerland</source>
        <translation>Weberstrasse 5, 8004 Zürich, Switzerland</translation>
    </message>
    <message>
        <location filename="dialogs/about/AboutDialog.py" line="38"/>
        <source>Contact:</source>
        <translation>Kontakt:</translation>
    </message>
</context>
<context>
    <name>DbObj</name>
    <message>
        <location filename="dbtools/dbTools.py" line="187"/>
        <source>DB-Error</source>
        <translation>DB-Fehler</translation>
    </message>
    <message>
        <location filename="dbtools/dbTools.py" line="241"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="dbtools/dbTools.py" line="224"/>
        <source>Only objects table or view can be checked</source>
        <translation>Nur Tabellen oder Views können geprüft werden</translation>
    </message>
    <message>
        <location filename="dbtools/dbTools.py" line="241"/>
        <source>This method is not supported by the connected DB-System</source>
        <translation>Diese Methode wird nicht von dem verbundenen Datenbank-System unterstützt</translation>
    </message>
    <message>
        <location filename="dbtools/dbTools.py" line="90"/>
        <source>Error: &apos;%s&apos;. The connection to the database could not be established! Some functions of the PlugIn %s may not work!</source>
        <translation>Fehler: &apos;%s&apos;. Die Verbindung zur Datenbank konnte nicht hergestellt werden! Einige Funktionalitäten des Plugins %s könnten nicht verfügbar sein!</translation>
    </message>
</context>
<context>
    <name>LandUseDialog</name>
    <message>
        <location filename="layerutils/LandUseDialog.py" line="61"/>
        <source>Set to selected management unit</source>
        <translation>Setzte auf selektierte Bewirtschaftungseinheit</translation>
    </message>
    <message>
        <location filename="layerutils/LandUseDialog.py" line="62"/>
        <source>Highlight parent management unit</source>
        <translation>Bewirtschaftungseinheit markieren</translation>
    </message>
    <message>
        <location filename="layerutils/LandUseDialog.py" line="105"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="layerutils/LandUseDialog.py" line="105"/>
        <source>Please select exactly one management unit</source>
        <translation>Bitte genau eine Bewirtschaftungseinheit auswählen</translation>
    </message>
    <message>
        <location filename="layerutils/LandUseDialog.py" line="118"/>
        <source>No match</source>
        <translation>Kein Treffer</translation>
    </message>
    <message>
        <location filename="layerutils/LandUseDialog.py" line="118"/>
        <source>Parent management unit is invalid</source>
        <translation>Bewirtschaftungseinheit existiert nicht</translation>
    </message>
</context>
<context>
    <name>LnfSchwyzPlugin</name>
    <message>
        <location filename="lnfschwyzplugin.py" line="55"/>
        <source>LNF-SZ</source>
        <translation>LNF-SZ</translation>
    </message>
    <message>
        <location filename="lnfschwyzplugin.py" line="58"/>
        <source>Initialize</source>
        <translation>Initialisieren</translation>
    </message>
    <message>
        <location filename="lnfschwyzplugin.py" line="59"/>
        <source>Search</source>
        <translation>Suche</translation>
    </message>
    <message>
        <location filename="lnfschwyzplugin.py" line="60"/>
        <source>Adjust land use units</source>
        <translation>Landnutzungseinheiten anpassen</translation>
    </message>
    <message>
        <location filename="lnfschwyzplugin.py" line="61"/>
        <source>Preferences</source>
        <translation>Einstellungen</translation>
    </message>
    <message>
        <location filename="lnfschwyzplugin.py" line="62"/>
        <source>About</source>
        <translation>Plugininformation</translation>
    </message>
    <message>
        <location filename="lnfschwyzplugin.py" line="175"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="lnfschwyzplugin.py" line="111"/>
        <source>No database connection set up, the plugin cannot proceed.</source>
        <translation>Keine Datenbankverbindung ist eingerichtet, das Plugin kann nicht fortsetzten.</translation>
    </message>
    <message>
        <location filename="lnfschwyzplugin.py" line="118"/>
        <source>Unable to connect to the database, the plugin cannot proceed.</source>
        <translation>Die Verbindung zur Datenbank ist fehlgeschlagen, das Plugin kann nicht fortsetzten.</translation>
    </message>
    <message>
        <location filename="lnfschwyzplugin.py" line="63"/>
        <source>Help</source>
        <translation>Hilfe</translation>
    </message>
    <message>
        <location filename="lnfschwyzplugin.py" line="405"/>
        <source>Orphan land use units</source>
        <translation>Waise Landnutzungseinheiten</translation>
    </message>
</context>
<context>
    <name>SearchDialog</name>
    <message>
        <location filename="dialogs/search/SearchDialog.py" line="109"/>
        <source>No parcels</source>
        <translation>Keine Grundstücke</translation>
    </message>
    <message>
        <location filename="dialogs/search/SearchDialog.py" line="129"/>
        <source>No companies</source>
        <translation>Keine Betriebe</translation>
    </message>
    <message>
        <location filename="dialogs/search/SearchDialog.py" line="156"/>
        <source>No results</source>
        <translation>Keine Resultate</translation>
    </message>
    <message>
        <location filename="dialogs/search/SearchDialog.py" line="156"/>
        <source>No results were found</source>
        <translation>Keine Resultate wurden gefunden</translation>
    </message>
    <message>
        <location filename="dialogs/search/SearchDialog.py" line="59"/>
        <source>Missing column</source>
        <translation>Fehlende Spalte</translation>
    </message>
    <message>
        <location filename="dialogs/search/SearchDialog.py" line="59"/>
        <source>The column &apos;%s&apos; is missing in &apos;%s&apos;.</source>
        <translation>Die Spalte &apos;%s&apos; fehlt in &apos;%s&apos;.</translation>
    </message>
    <message>
        <location filename="dialogs/search/SearchDialog.py" line="42"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="dialogs/search/SearchDialog.py" line="42"/>
        <source>Unable to connect to the database, search will not work.</source>
        <translation>Datenbankverbindung schlug fehlt, Suche wird nicht funktionieren.</translation>
    </message>
    <message>
        <location filename="dialogs/search/SearchDialog.py" line="33"/>
        <source>Select features</source>
        <translation>Objekte selektieren</translation>
    </message>
</context>
<context>
    <name>aboutDialog</name>
    <message>
        <location filename="dialogs/about/ui_about.py" line="108"/>
        <source>About</source>
        <translation>Über</translation>
    </message>
    <message>
        <location filename="dialogs/about/ui_about.py" line="109"/>
        <source>Version:</source>
        <translation>Version:</translation>
    </message>
    <message>
        <location filename="dialogs/about/ui_about.py" line="110"/>
        <source>About </source>
        <translation>Plugininformation </translation>
    </message>
    <message>
        <location filename="dialogs/about/ui_about.py" line="111"/>
        <source>Contributors</source>
        <translation>Beitragende</translation>
    </message>
    <message>
        <location filename="dialogs/about/ui_about.py" line="112"/>
        <source>Contact</source>
        <translation>Kontakt</translation>
    </message>
    <message>
        <location filename="dialogs/about/ui_about.py" line="113"/>
        <source>Change Log</source>
        <translation>Changelog</translation>
    </message>
</context>
<context>
    <name>searchDlg</name>
    <message>
        <location filename="dialogs/search/ui_search.py" line="82"/>
        <source>Search</source>
        <translation>Suche</translation>
    </message>
    <message>
        <location filename="dialogs/search/ui_search.py" line="83"/>
        <source>Parcel No.:</source>
        <translation>Grundstück Nr.:</translation>
    </message>
    <message>
        <location filename="dialogs/search/ui_search.py" line="84"/>
        <source>Company No.:</source>
        <translation>Betriebs Nr.:</translation>
    </message>
    <message>
        <location filename="dialogs/search/ui_search.py" line="85"/>
        <source>Municipality:</source>
        <translation>Gemeinde:</translation>
    </message>
    <message>
        <location filename="dialogs/search/ui_search.py" line="86"/>
        <source>Zoom to:</source>
        <translation>Auf Auswahl Zoomen</translation>
    </message>
    <message>
        <location filename="dialogs/search/ui_search.py" line="87"/>
        <source>Zaehlkreis:</source>
        <translation>Zählkreis:</translation>
    </message>
</context>
<context>
    <name>settingsDialog</name>
    <message>
        <location filename="dialogs/settings/ui_settingsDialog.py" line="80"/>
        <source>Settings</source>
        <translation>Einstellungen</translation>
    </message>
    <message>
        <location filename="dialogs/settings/ui_settingsDialog.py" line="81"/>
        <source>Database connection</source>
        <translation>Datenbankverbindung</translation>
    </message>
    <message>
        <location filename="dialogs/settings/ui_settingsDialog.py" line="82"/>
        <source>Host:</source>
        <translation>Host:</translation>
    </message>
    <message>
        <location filename="dialogs/settings/ui_settingsDialog.py" line="83"/>
        <source>Port:</source>
        <translation>Port:</translation>
    </message>
    <message>
        <location filename="dialogs/settings/ui_settingsDialog.py" line="84"/>
        <source>DB Name:</source>
        <translation>DB Name:</translation>
    </message>
    <message>
        <location filename="dialogs/settings/ui_settingsDialog.py" line="85"/>
        <source>Username:</source>
        <translation>Benutzername:</translation>
    </message>
    <message>
        <location filename="dialogs/settings/ui_settingsDialog.py" line="86"/>
        <source>Password:</source>
        <translation>Passwort:</translation>
    </message>
</context>
</TS>
