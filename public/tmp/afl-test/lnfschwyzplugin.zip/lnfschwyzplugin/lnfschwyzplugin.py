# -*- coding: utf-8 -*-
#
#    LnfSchwyzPlugin - Checking quality rules when LNF data is captured
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    copyright            : (C) 2014 by Sandro Mani / Sourcepole AG
#    email                : smani@sourcepole.ch

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from qgis.gui import *
import os
import site
import subprocess
import sys
import re

from dbtools.dbTools import DbObj
from dialogs.about.AboutDialog import AboutDialog
from dialogs.search.SearchDialog import SearchDialog
from dialogs.settings.SettingsDialog import SettingsDialog
from layerutils.LayerUtils import LayerUtils
from layerutils.LandUseUtils import LandUseUtils
from layerutils.CompanyUtils import CompanyUtils
from layerutils.ManagementUnitsUtils import ManagementUnitsUtils


class LnfSchwyzPlugin(QObject):
    def __init__(self, iface):
        QObject.__init__(self)

        self.iface = iface
        self.pluginDir = os.path.dirname(__file__)
        self.haveProject = False

        # Localize
        locale = QSettings().value("locale/userLocale")[0:2]
        localePath = os.path.join(self.pluginDir, 'i18n', 'lnfschwyz_{}.qm'.format(locale))

        if os.path.exists(localePath):
            self.translator = QTranslator()
            self.translator.load(localePath)
            QCoreApplication.installTranslator(self.translator)

        # Add python path for ui init functions
        site.addsitedir(os.path.join(self.pluginDir, 'layerutils'))

    def initGui(self):
        self.menu = QMenu()
        self.menu.setTitle(self.tr("LNF-SZ"))

        # Create actions
        self.actionInit = QAction(QIcon(""), self.tr("Initialize"), self.iface.mainWindow())
        self.actionSearch = QAction(QIcon(""), self.tr("Search"), self.iface.mainWindow())
        self.adjustLandUseAction = QAction(QIcon(""), self.tr("Adjust land use units"), self.iface.mainWindow())
        self.prefsAction = QAction(QIcon(""), self.tr("Preferences"), self.iface.mainWindow())
        self.aboutAction = QAction(QIcon(""), self.tr("About"), self.iface.mainWindow())
        self.helpAction = QAction(QIcon(""), self.tr("Help"), self.iface.mainWindow())

        self.actionSearch.setEnabled(False)
        self.adjustLandUseAction.setEnabled(False)

        # connect the action to the run method
        self.actionInit.triggered.connect(self.onInitTriggered)
        self.actionSearch.triggered.connect(self.doSearch)
        self.adjustLandUseAction.triggered.connect(self.adjustLandUseFeatures)
        self.prefsAction.triggered.connect(self.doSettings)
        self.aboutAction.triggered.connect(self.doAbout)
        self.helpAction.triggered.connect(self.doHelp)

        self.menu.addActions([self.actionInit, self.actionSearch, self.adjustLandUseAction, self.prefsAction, self.aboutAction, self.helpAction])
        self.menu.insertSeparator(self.prefsAction)

        self.iface.mainWindow().menuBar().addMenu(self.menu)
        self.iface.projectRead.connect(self.onProjectRead)
        QgsMapLayerRegistry.instance().removeAll.connect(self.uninit)
        self.iface.mapCanvas().extentsChanged.connect(self.saveExtents)

    def unload(self):
        try:
            self.menu.deleteLater()
        except:
            pass
        self.uninit()

    def onProjectRead(self):
        if QgsProject.instance().readEntry("lnf", "isLnfProject", "")[0] == "yes":
            self.iface.mainWindow().setCursor(Qt.BusyCursor)
            self.doInit()
            self.iface.mainWindow().unsetCursor()

    def onInitTriggered(self):
        self.iface.newProject(True)
        # If new project was created
        if not QgsProject.instance().isDirty():
            self.iface.mainWindow().setCursor(Qt.BusyCursor)
            self.doInit()
            self.iface.mainWindow().unsetCursor()

    def doInit(self):
        # Get connection URI
        self.dbUri = SettingsDialog().getDBConnectionURI()
        if not self.dbUri:
            self.dbUri = SettingsDialog().run()
        if not self.dbUri:
            QMessageBox.critical(self.iface.mainWindow(), self.tr("Error"), self.tr("No database connection set up, the plugin cannot proceed."))
            return
        ds = QgsDataSourceURI(self.dbUri)

        # Try opening DB
        db = DbObj("LNF-SZ", "pg", ds.host(), ds.port(), ds.database(), ds.username(), ds.password())
        if not db.isOpen():
            QMessageBox.critical(self.iface.mainWindow(), self.tr("Error"), self.tr("Unable to connect to the database, the plugin cannot proceed."))
            return
        db.close()

        # Load layers
        self.iface.mapCanvas().freeze(True)
        try:
            auxGroup = self.iface.legendInterface().groups().index("Hilfstabellen")
        except:
            auxGroup = self.iface.legendInterface().addGroup("Hilfstabellen", False)
        try:
            # Nutzungseinheiten (flaechen)
            ds.setDataSource("a002a", "nutzung_flaeche_v", "gm_flaeche", "", "gid")
            ds.setSrid("2056")
            ds.setWkbType(QGis.WKBPolygon)
            self.luLayer = LayerUtils.load(self.iface, ds, "luLayer", u"Nutzungseinheiten (Flaechen)")

            # Nutzungseinheiten (points)
            ds.setDataSource("a002a", "nutzung_punkt_v", "gm_punkt", "", "gid")
            ds.setSrid("2056")
            ds.setWkbType(QGis.WKBPoint)
            self.lupLayer = LayerUtils.load(self.iface, ds, "lupLayer", "Nutzungseinheiten (Punkte)")

            # Bewirtschaftungseinheiten
            ds.setDataSource("a001a", "bewirtschaftungseinheit_v", "gm_flaeche", "", "gid")
            ds.setSrid("2056")
            ds.setWkbType(QGis.WKBPolygon)
            self.muLayer = LayerUtils.load(self.iface, ds, "muLayer", "Bewirtschaftungseinheiten")

            # AV-Daten
            ds.setDataSource("a004b", "r20a00_own_realestate", "geometry")
            ds.setSrid("2056")
            ds.setWkbType(QGis.WKBPolygon)
            self.parcelLayer = LayerUtils.load(self.iface, ds, "parcelLayer", "AV-Daten")

            # Betriebe
            ds.setDataSource("a001a", "betrieb_v", "gm_punkt", "", "gid")
            ds.setSrid("2056")
            ds.setWkbType(QGis.WKBPoint)
            self.coLayer = LayerUtils().load(self.iface, ds, "coLayer", "Betriebe")

            ds.setSrid("")
            ds.setWkbType(QGis.WKBUnknown)

            # nutzungsart_v
            ds.setDataSource("a024", "nutzungsart_v", None, aKeyColumn="id")
            self.txNutzungsartLayer = LayerUtils.load(self.iface, ds, "txNutzungsartLayer", "Text_Nutzungsart", auxGroup)

            # status_v
            ds.setDataSource("a025", "status_v", None, aKeyColumn="id")
            self.txStatusLayer = LayerUtils.load(self.iface, ds, "txStatusLayer", "Text_Status", auxGroup)

            # betrieb_txt_v
            ds.setDataSource("a001a", "betrieb_txt_v", None, aKeyColumn="id")
            self.txBetriebLayer = LayerUtils.load(self.iface, ds, "txBetriebLayer", "Text_Betrieb", auxGroup)

        except Exception as e:
            QMessageBox.critical(self.iface.mainWindow(), self.tr("Error"), str(e))
            return

        svgPaths = [path for path in QSettings().value( "svg/searchPathsForSVG", "" ).split("|") if path]
        stylePath = self.pluginDir + "/legenden/"
        if stylePath not in svgPaths:
            svgPaths.append(stylePath)
            QSettings().setValue("svg/searchPathsForSVG", "|".join(svgPaths))
        self.luLayer.loadNamedStyle(stylePath + "Nutzungseinheiten_Flaechen.qml")
        self.lupLayer.loadNamedStyle(stylePath + "Nutzungseinheiten_Punkte.qml")
        self.muLayer.loadNamedStyle(stylePath + "Bewirtschaftungseinheiten.qml")
        self.coLayer.loadNamedStyle(stylePath + "Betriebe.qml")
        self.parcelLayer.loadNamedStyle(stylePath + "Liegenschaften.qml")
        self.iface.legendInterface().refreshLayerSymbology(self.luLayer)
        self.iface.legendInterface().refreshLayerSymbology(self.lupLayer)
        self.iface.legendInterface().refreshLayerSymbology(self.muLayer)
        self.iface.legendInterface().refreshLayerSymbology(self.coLayer)
        self.iface.legendInterface().refreshLayerSymbology(self.parcelLayer)
        ManagementUnitsUtils.setupAttributeDialog(self.muLayer, self.txStatusLayer, self.txBetriebLayer)
        LandUseUtils.setupAttributeDialog(self.luLayer, self.txStatusLayer, self.txNutzungsartLayer)
        LandUseUtils.setupAttributeDialog(self.lupLayer, self.txStatusLayer, self.txNutzungsartLayer)
        CompanyUtils.setupAttributeDialog(self.coLayer)

        # Connect signals
        self.muLayer.featureAdded.connect(self.queueManagementUnitAdded)
        # self.muLayer.geometryChanged.connect(self.checkManagementUnitGeometry)
        QObject.connect(self.muLayer, SIGNAL("geometryChanged(QgsFeatureId, QgsGeometry&)"), self.queueCheckManagementUnitGeometry)
        self.muLayer.featureDeleted.connect(self.managementFeatureDeleted)
        self.muLayer.editingStarted.connect(lambda: self.setEditingManagementLayer(True))
        self.muLayer.beforeRollBack.connect(lambda: self.setEditingManagementLayer(False))
        self.muLayer.beforeCommitChanges.connect(lambda: self.setEditingManagementLayer(False))

        self.luLayer.featureAdded.connect(self.queueLandUseFeatureAdded)
        # self.luLayer.geometryChanged.connect(self.checkLandUseGeometry)
        QObject.connect(self.luLayer, SIGNAL("geometryChanged(QgsFeatureId, QgsGeometry&)"), self.queueCheckLandUseGeometry)
        self.luLayer.editingStarted.connect(lambda: self.setEditingLandUseLayer(True))
        self.luLayer.beforeRollBack.connect(lambda: self.setEditingLandUseLayer(False))
        self.luLayer.beforeCommitChanges.connect(lambda: self.setEditingLandUseLayer(False))

        self.lupLayer.featureAdded.connect(self.queueLandUsePointFeatureAdded)
        # self.lupLayer.geometryChanged.connect(self.checkLandUsePointGeometry)
        QObject.connect(self.lupLayer, SIGNAL("geometryChanged(QgsFeatureId, QgsGeometry&)"), self.queueCheckLandUsePointGeometry)
        self.lupLayer.editingStarted.connect(lambda: self.setEditingLandUsePointLayer(True))
        self.lupLayer.beforeRollBack.connect(lambda: self.setEditingLandUsePointLayer(False))
        self.lupLayer.beforeCommitChanges.connect(lambda: self.setEditingLandUsePointLayer(False))

        self.coLayer.featureAdded.connect(self.queueCompanyAdded)
        self.coLayer.editingStarted.connect(lambda: self.setEditingCompanyLayer(True))
        self.coLayer.beforeRollBack.connect(lambda: self.setEditingCompanyLayer(False))
        self.coLayer.beforeCommitChanges.connect(lambda: self.setEditingCompanyLayer(False))

        self.iface.actionSplitFeatures().toggled.connect(self.setShowAttributeDialog)

        # Set initial extent
        extent = QgsProject.instance().readEntry("lnf", "extent", "")[0]
        try:
            coords = [float(x) for x in re.split(r"[\s,]+", extent)]
            extent = QgsRectangle(coords[0], coords[1], coords[2], coords[3])
        except:
            p = self.luLayer.extent().center()
            extent = QgsRectangle(p.x() - 3000, p.y() - 3000, p.x() + 3000, p.y() + 3000)
        self.iface.mapCanvas().setExtent(extent)
        self.iface.mapCanvas().freeze(False)
        self.iface.mapCanvas().refresh()
        self.actionSearch.setEnabled(True)
        QgsProject.instance().writeEntry("lnf", "isLnfProject", "yes")
        self.haveProject = True

        self.editingMuLayer = False
        self.editingLuLayer = False
        self.editingLupLayer = False
        self.editingCoLayer = False
        self.showAttributesDialog = False
        self.attributesDialogVisible = False
        self.showAttributesDialogQueue = []

    def uninit(self):
        self.actionSearch.setEnabled(False)
        self.haveProject = False
        try:
            self.searchDlg.hide()
        except:
            pass

    def setShowAttributeDialog(self, show):
        self.showAttributesDialog = show

    def runAttributesDialog(self, layer, id):
        if not self.showAttributesDialog:
            return
        self.showAttributesDialogQueue.append([layer, id])
        if self.attributesDialogVisible:
            return
        self.attributesDialogVisible = True
        while len(self.showAttributesDialogQueue) is not 0:
            layer, id = self.showAttributesDialogQueue[0]
            feature = LayerUtils.getFeatureById(layer, id)

            # Highlight the feature in question
            rb = QgsRubberBand(self.iface.mapCanvas(), True)
            rb.setColor(Qt.yellow)
            rb.setWidth(2)
            rb.setToGeometry(feature.geometry(), layer)

            dialog = QgsAttributeDialog(layer, feature, False)
            # Work around exec being a reserved keyword
            exec_ = getattr(dialog, "exec")
            exec_()

            self.iface.mapCanvas().scene().removeItem(rb)
            QMetaObject.invokeMethod(self.iface.mapCanvas(), "refresh", Qt.QueuedConnection)
            self.showAttributesDialogQueue.pop(0)
        self.attributesDialogVisible = False

    ###########################################################################

    def setEditingLandUseLayer(self, editing):
        self.editingLuLayer = editing
        # Allow editing only one layer at a time
        self.coLayer.setReadOnly(editing)
        self.muLayer.setReadOnly(editing)
        self.lupLayer.setReadOnly(editing)

    def queueLandUseFeatureAdded(self, id):
        # Ensure calling function has ended
        if self.editingLuLayer:
            QMetaObject.invokeMethod(self, "landUseFeatureAdded", Qt.QueuedConnection, Q_ARG(int, id))

    def queueCheckLandUseGeometry(self, id, geometry):
        # Ensure calling function has ended
        if self.editingLuLayer:
            QMetaObject.invokeMethod(self, "checkLandUseGeometry", Qt.QueuedConnection, Q_ARG(int, id))

    @pyqtSlot(int)
    def landUseFeatureAdded(self, id):
        if self.editingLuLayer:
            LandUseUtils.checkGeometry(self.luLayer, self.muLayer, id)
            self.runAttributesDialog(self.luLayer, id)

    @pyqtSlot(int)
    def checkLandUseGeometry(self, id):
        if self.editingLuLayer:
            LandUseUtils.checkGeometry(self.luLayer, self.muLayer, id)

    def adjustLandUseFeatures(self):
        if LandUseUtils.adjustLandUseFeatures(self.luLayer, self.muLayer, self.changedMUBBox, self.iface):
            self.changedMUBBox = None
            self.adjustLandUseAction.setEnabled(False)

    ###########################################################################

    def setEditingLandUsePointLayer(self, editing):
        self.editingLupLayer = editing
        # Allow editing only one layer at a time
        self.coLayer.setReadOnly(editing)
        self.muLayer.setReadOnly(editing)
        self.luLayer.setReadOnly(editing)

    def queueLandUsePointFeatureAdded(self, id):
        # Ensure calling function has ended
        if self.editingLupLayer:
            QMetaObject.invokeMethod(self, "landUsePointFeatureAdded", Qt.QueuedConnection, Q_ARG(int, id))

    def queueCheckLandUsePointGeometry(self, id, geometry):
        # Ensure calling function has ended
        if self.editingLupLayer:
            QMetaObject.invokeMethod(self, "checkLandUsePointGeometry", Qt.QueuedConnection, Q_ARG(int, id))

    @pyqtSlot(int)
    def landUsePointFeatureAdded(self, id):
        if self.editingLupLayer:
            LandUseUtils.checkGeometry(self.lupLayer, self.muLayer, id)
            self.runAttributesDialog(self.lupLayer, id)

    @pyqtSlot(int)
    def checkLandUsePointGeometry(self, id):
        if self.editingLupLayer:
            LandUseUtils.checkGeometry(self.lupLayer, self.muLayer, id)

    ###########################################################################

    def setEditingManagementLayer(self, editing):
        self.editingMuLayer = editing
        self.adjustLandUseAction.setEnabled(False)
        # Set of mu features ids changed in a session, used by adjustLandUseFeatures
        self.changedMUBBox = None
        # Whether any MUs were created (adjustLandUseFeatures is disabled in that case)
        self.MUsCreated = False
        # id => geometry dictionary of mu features changed, used by managementFeatureDeleted
        self.editedMUs = dict()
        # Allow editing only one layer at a time
        self.coLayer.setReadOnly(editing)
        self.luLayer.setReadOnly(editing)
        self.lupLayer.setReadOnly(editing)

    def queueManagementUnitAdded(self, id):
        # Ensure calling function has ended
        if self.editingMuLayer:
            QMetaObject.invokeMethod(self, "managementUnitAdded", Qt.QueuedConnection, Q_ARG(int, id))

    def queueCheckManagementUnitGeometry(self, id, geometry):
        # Ensure calling function has ended
        if self.editingMuLayer:
            QMetaObject.invokeMethod(self, "checkManagementUnitGeometry", Qt.QueuedConnection, Q_ARG(int, id))

    @pyqtSlot(int)
    def managementUnitAdded(self, id):
        if self.editingMuLayer:
            ManagementUnitsUtils.checkGeometry(self.muLayer, self.luLayer, id, self.editedMUs)
            self.runAttributesDialog(self.muLayer, id)
            self.MUsCreated = True
            self.adjustLandUseAction.setEnabled(False)

    @pyqtSlot(int)
    def checkManagementUnitGeometry(self, id):
        if self.editingMuLayer:
            feature = LayerUtils.getFeatureById(self.muLayer, id)
            ManagementUnitsUtils.checkGeometry(self.muLayer, self.luLayer, id, self.editedMUs)
            if not self.changedMUBBox:
                self.changedMUBBox = feature.geometry().boundingBox()
            else:
                self.changedMUBBox.combineExtentWith(feature.geometry().boundingBox())
            self.editedMUs[id] = QgsGeometry(feature.geometry())
            if id < 0:
                self.MUsCreated = True
            self.adjustLandUseAction.setEnabled(not self.MUsCreated)

    def managementFeatureDeleted(self, id):
        if self.editingMuLayer:
            try:
                bbox = ManagementUnitsUtils.getOldGeometry(self.muLayer, id, self.editedMUs).boundingBox()
            except:
                return
            for luFeature in LayerUtils.getFeaturesByBoundingBox(self.luLayer, bbox):
                if not LandUseUtils.getParentManagementUnit(self.muLayer, luFeature):
                    QMessageBox.warning(None, self.tr("Orphan land use units"), "The deleted management unit contained land use units which are now orphans.")
                    break

    ###########################################################################

    def setEditingCompanyLayer(self, editing):
        self.editingCoLayer = editing
        # Allow editing only one layer at a time
        self.muLayer.setReadOnly(editing)
        self.luLayer.setReadOnly(editing)
        self.lupLayer.setReadOnly(editing)

    def queueCompanyAdded(self, id):
        # Ensure calling function has ended
        if self.editingCoLayer:
            QMetaObject.invokeMethod(self, "companyAdded", Qt.QueuedConnection, Q_ARG(int, id))

    @pyqtSlot(int)
    def companyAdded(self, id):
        if self.editingCoLayer:
            self.runAttributesDialog(self.coLayer, id)

    ###########################################################################

    def doSearch(self):
        self.searchDlg = SearchDialog(self.iface, self.dbUri, self.luLayer, self.muLayer, self.parcelLayer)
        self.searchDlg.show()

    def doSettings(self):
        SettingsDialog().run()

    def doAbout(self):
        AboutDialog(self.pluginDir).exec_()

    def doHelp(self):
        filepath = os.path.join(self.pluginDir, "help", "documentation.pdf")
        if sys.platform.startswith('darwin'):
            subprocess.call(('open', filepath))
        elif os.name == 'nt':
            os.startfile(filepath)
        elif os.name == 'posix':
            subprocess.call(('xdg-open', filepath))

    def saveExtents(self):
        if self.haveProject:
            QgsProject.instance().writeEntry("lnf", "extent", self.iface.mapCanvas().extent().asWktCoordinates())
